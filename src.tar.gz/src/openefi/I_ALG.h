// TODO:
#ifndef _I_ALG_h
#define _I_ALG_h
#include "defines.h"

class I_ALG{
public:
    I_ALG(); //bob el constructor de funciones, nada raro por ahora
private:
};

#endif